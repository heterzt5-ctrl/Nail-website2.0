# 🎯 Editorial System - Complete Integration Guide

## 📦 Files Created

```
/components/editorial/
├── EditorialImage.tsx      # Image component with integrated lightbox
├── EditorialGrid.tsx       # Asymmetrical grid with lightbox
├── ArticleRenderer.tsx     # Content block renderer
└── 
/app/editorial/[slug]/
└── article-client-final.tsx # Main page component
```

---

## 🚀 Installation Steps

### 1. Copy Components

Copy these 3 files to your project:
- `EditorialImage.tsx` → `/components/editorial/`
- `EditorialGrid.tsx` → `/components/editorial/`
- `ArticleRenderer.tsx` → `/components/editorial/`

### 2. Replace Main Article Page

Replace your current `article-client.tsx` with `article-client-final.tsx`

```bash
# Old file
src/app/editorial/[slug]/article-client.tsx

# New file
src/app/editorial/[slug]/article-client-final.tsx
```

### 3. Update Data Structure

Your `Post` type needs these fields (if using blocks-based content):

```typescript
interface Post {
  id: string;
  slug: string;
  title_vn: string;
  title_en: string;
  title_kr?: string;
  title_cn?: string;
  title_ru?: string;
  
  category_vn: string;
  category_en: string;
  category_kr?: string;
  category_cn?: string;
  category_ru?: string;
  
  excerpt_vn: string;
  excerpt_en: string;
  excerpt_kr?: string;
  excerpt_cn?: string;
  excerpt_ru?: string;
  
  // Body as plain text (will be converted to blocks)
  body_vn: string;
  body_en: string;
  body_kr?: string;
  body_cn?: string;
  body_ru?: string;
  
  read_time_vn: string;
  read_time_en: string;
  read_time_kr?: string;
  read_time_cn?: string;
  read_time_ru?: string;
  
  cover_image_url: string;
  author: string;
  published_date?: string;
  created_at: string;
}
```

---

## 📝 Usage Examples

### Example 1: Simple Article (Text Only)

```typescript
const post: Post = {
  id: "1",
  slug: "nail-art-guide",
  title_vn: "Hướng Dẫn Nail Art",
  title_en: "Nail Art Guide",
  excerpt_vn: "Khám phá những kỹ thuật cơ bản...",
  excerpt_en: "Discover fundamental techniques...",
  body_vn: `
    Paragraph 1 về nail art...

    Paragraph 2 tiếp tục cuộc hành trình...

    Paragraph 3 kết luận...
  `,
  body_en: `
    Paragraph 1 about nail art...

    Paragraph 2 continuing the journey...

    Paragraph 3 conclusion...
  `,
  category_vn: "Hướng Dẫn",
  category_en: "Tutorial",
  read_time_vn: "5 Phút Đọc",
  read_time_en: "5 MIN READ",
  cover_image_url: "/images/nail-hero.jpg",
  author: "Remy Muse",
  published_date: "2024-05-15",
  created_at: "2024-05-15",
};
```

### Example 2: Article with Images (Advanced)

Để thêm hình ảnh vào bài viết, bạn cần convert `body` thành `blocks` format:

```typescript
// Thay vì body_vn, body_en...
// Dùng blocks array:

interface PostWithBlocks extends Post {
  blocks: (TextBlock | ImageBlock | GridBlock)[];
}

const advancedPost: PostWithBlocks = {
  // ...post fields same as above
  blocks: [
    {
      type: "text",
      content: "Đây là đoạn mở đầu của bài viết...",
    },
    {
      type: "image",
      src: "/images/technique-1.jpg",
      alt: "Kỹ thuật cơ bản",
      caption: "Bước 1: Chuẩn bị móng",
      variant: "contained", // hoặc "full" hoặc "offset"
    },
    {
      type: "text",
      content: "Tiếp theo, chúng ta sẽ khám phá...",
    },
    {
      type: "grid",
      images: [
        { src: "/images/design-1.jpg", alt: "Design 1" },
        { src: "/images/design-2.jpg", alt: "Design 2" },
        { src: "/images/design-3.jpg", alt: "Design 3" },
      ],
    },
    {
      type: "text",
      content: "Cuối cùng, hãy nhớ rằng...",
    },
  ],
};
```

---

## 🖼️ Image Variants

### 1. **Contained** (Default)
- Ảnh nằm trong khung article width
- Aspect ratio 16:10
- Tốt cho: hình minh họa, so sánh trước/sau

```tsx
<EditorialImage
  src="/image.jpg"
  variant="contained"
  caption="Optional caption"
/>
```

### 2. **Full** (Breakout)
- Ảnh chiếm toàn màn hình
- Height: 50vh (mobile) → 70vh (desktop)
- Tốt cho: hero shots, landscape photography

```tsx
<EditorialImage
  src="/image.jpg"
  variant="full"
  caption="Full-width caption"
/>
```

### 3. **Offset** (Luxury)
- Ảnh được đặt offset bên phải
- Aspect ratio 4:5 (portrait)
- Tốt cho: fashion, beauty, high-end aesthetic

```tsx
<EditorialImage
  src="/image.jpg"
  variant="offset"
  caption="Offset luxury style"
/>
```

---

## 🎨 Grid Layouts

### Asymmetrical Grid
Tự động tạo layout cân bằng:
- 1 large image (left, 7/12 columns)
- 2 small images (right, 5/12 columns)
- Nếu có 4+ hình: thêm row dưới with 3 columns

```tsx
<EditorialGrid
  images={[
    { src: "/img1.jpg", alt: "Main" },
    { src: "/img2.jpg", alt: "Secondary 1" },
    { src: "/img3.jpg", alt: "Secondary 2" },
    { src: "/img4.jpg", alt: "Additional" },
    { src: "/img5.jpg", alt: "Additional" },
  ]}
/>
```

---

## 💡 Lightbox Features

Tất cả image components đều có integrated lightbox:

✅ **Zoom & Pan**
- Cuộn chuột: phóng to/thu nhỏ (1x → 4x)
- Kéo ảnh: di chuyển khi phóng to
- Nút +/- để zoom chính xác

✅ **Navigation**
- Click X hoặc nền đen: thoát
- Phím ESC: thoát (auto-enabled)
- Thanh controls ở dưới

✅ **Grid Lightbox Bonus**
- Mũi tên trái/phải: duyệt qua ảnh
- Hiển thị số thứ tự (1/5)
- Reset button

---

## 🔧 Customization

### Thay đổi màu sắc

Tất cả components dùng color variables. Để thay đổi, edit:

```tsx
// EditorialImage.tsx
className="bg-[#F8F7F4]" // Background
className="text-[#735c00]" // Accent color
className="text-[#1b1c19]" // Text color
```

### Thay đổi spacing

```tsx
// EditorialImage.tsx
my-16 md:my-24      // Margin vertical
my-28               // Grid margin
rounded-lg          // Border radius
```

### Thay đổi animation

```tsx
// Framer Motion settings
transition={{ type: "spring", stiffness: 400, damping: 30 }}
```

---

## 📱 Responsive Breakpoints

Tất cả components fully responsive:

```
Mobile: < 768px
Tablet: 768px - 1024px
Desktop: > 1024px
```

Grid layout tự động adjust:
- Mobile: Full width stacked
- Tablet: 2 columns
- Desktop: Asymmetrical 7/5 split

---

## ⚡ Performance Tips

1. **Image Optimization**
   - Use Next.js Image component (already done)
   - Provide correct aspect ratios
   - Add `sizes` prop for responsive loading

2. **Lazy Loading**
   - Images outside viewport load on demand
   - Lightbox images load on first open

3. **Animation Performance**
   - Lightbox animations use GPU-accelerated transforms
   - No heavy layouts recalculation

---

## 🐛 Troubleshooting

### Q: Ảnh không hiển thị
A: Check `src` path, ensure image exists at `/public/...`

### Q: Lightbox không hoạt động
A: Ensure Framer Motion installed: `npm install framer-motion`

### Q: Text không căn đúng
A: Verify Post type matches expected structure

### Q: Grid layout bị lệch
A: Grid components expect array of images, ensure correct structure

---

## 📚 File Dependencies

```
article-client-final.tsx
├── EditorialImage.tsx (import)
├── EditorialGrid.tsx (import)
├── ArticleRenderer.tsx (import)
├── Header.tsx (existing)
├── Footer.tsx (existing)
├── BookingModal.tsx (existing)
└── language-context.ts (existing)
```

Đảm bảo tất cả import paths đúng!

---

## 🎯 Next Steps

1. ✅ Copy 3 component files
2. ✅ Replace article-client.tsx
3. ✅ Test với sample Post data
4. ✅ Update Post structure nếu cần
5. ✅ Thêm hình ảnh vào articles
6. ✅ Customize colors/spacing nếu cần

Bạn đã sẵn sàng! 🚀
