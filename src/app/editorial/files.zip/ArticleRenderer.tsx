"use client";

import { EditorialImage } from "./EditorialImage";
import { EditorialGrid } from "./EditorialGrid";

interface TextBlock {
  type: "text";
  content: string;
}

interface ImageBlock {
  type: "image";
  src: string;
  alt?: string;
  caption?: string;
  variant?: "contained" | "full" | "offset";
}

interface GridBlock {
  type: "grid";
  images: { src: string; alt?: string }[];
}

type ContentBlock = TextBlock | ImageBlock | GridBlock;

interface ArticleRendererProps {
  blocks: ContentBlock[];
}

export function ArticleRenderer({ blocks }: ArticleRendererProps) {
  if (!blocks || blocks.length === 0) {
    return null;
  }

  return (
    <div className="max-w-[720px] mx-auto px-6 md:px-12">
      {blocks.map((block, i) => {
        if (block.type === "text") {
          return (
            <p
              key={i}
              className="font-serif text-lg md:text-xl leading-[1.9] text-[#1b1c19]/90 my-10 first:mt-0"
            >
              {block.content}
            </p>
          );
        }

        if (block.type === "image") {
          return (
            <EditorialImage
              key={i}
              src={block.src}
              alt={block.alt}
              caption={block.caption}
              variant={block.variant || "contained"}
            />
          );
        }

        if (block.type === "grid") {
          return (
            <div key={i} className="px-0 md:-mx-12">
              <EditorialGrid images={block.images} />
            </div>
          );
        }

        return null;
      })}
    </div>
  );
}
