"use client";

import Image from "next/image";
import { useState } from "react";
import { motion } from "framer-motion";
import { X, ZoomIn } from "lucide-react";

interface EditorialGridProps {
  images: { src: string; alt?: string }[];
}

export function EditorialGrid({ images }: EditorialGridProps) {
  if (!images || images.length < 2) return null;

  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  const openLightbox = (index: number) => {
    setSelectedImageIndex(index);
    setLightboxOpen(true);
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (zoom === 1) return;
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || zoom === 1) return;
    const newX = e.clientX - dragStart.x;
    const newY = e.clientY - dragStart.y;
    const maxPan = (zoom - 1) * 150;
    setPan({
      x: Math.max(-maxPan, Math.min(maxPan, newX)),
      y: Math.max(-maxPan, Math.min(maxPan, newY)),
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const zoomSpeed = 0.15;
    const newZoom = e.deltaY > 0 
      ? Math.max(1, zoom - zoomSpeed) 
      : Math.min(4, zoom + zoomSpeed);
    setZoom(newZoom);
    if (newZoom === 1) {
      setPan({ x: 0, y: 0 });
    }
  };

  const closeLightbox = () => {
    setLightboxOpen(false);
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  return (
    <>
      <div className="my-28 grid grid-cols-12 gap-6 md:gap-8">
        
        {/* Large image (left, takes 7 columns on desktop) */}
        <div 
          className="col-span-12 md:col-span-7 group cursor-pointer"
          onClick={() => openLightbox(0)}
        >
          <div className="relative aspect-[4/5] overflow-hidden rounded-lg bg-[#F8F7F4]">
            <Image 
              src={images[0].src} 
              alt={images[0].alt || ""}
              fill 
              className="object-cover group-hover:opacity-90 transition-opacity"
            />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center">
              <motion.div 
                className="opacity-0 group-hover:opacity-100 transition-opacity"
                initial={{ scale: 0.8 }}
                whileHover={{ scale: 1 }}
              >
                <ZoomIn className="w-6 h-6 text-white drop-shadow-lg" />
              </motion.div>
            </div>
          </div>
        </div>

        {/* Small stack (right, takes 5 columns on desktop) */}
        <div className="col-span-12 md:col-span-5 flex flex-col gap-6 md:gap-8">
          {images.slice(1, 3).map((img, i) => (
            <div 
              key={i}
              className="group cursor-pointer flex-1"
              onClick={() => openLightbox(i + 1)}
            >
              <div className="relative aspect-[4/5] overflow-hidden rounded-lg bg-[#F8F7F4]">
                <Image 
                  src={img.src} 
                  alt={img.alt || ""}
                  fill 
                  className="object-cover group-hover:opacity-90 transition-opacity"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center">
                  <motion.div 
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                    initial={{ scale: 0.8 }}
                    whileHover={{ scale: 1 }}
                  >
                    <ZoomIn className="w-6 h-6 text-white drop-shadow-lg" />
                  </motion.div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Additional images as full-width row if exists */}
        {images.length > 3 && (
          <div className="col-span-12 grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            {images.slice(3).map((img, i) => (
              <div 
                key={i}
                className="group cursor-pointer"
                onClick={() => openLightbox(i + 3)}
              >
                <div className="relative aspect-[4/5] overflow-hidden rounded-lg bg-[#F8F7F4]">
                  <Image 
                    src={img.src} 
                    alt={img.alt || ""}
                    fill 
                    className="object-cover group-hover:opacity-90 transition-opacity"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center">
                    <motion.div 
                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                      initial={{ scale: 0.8 }}
                      whileHover={{ scale: 1 }}
                    >
                      <ZoomIn className="w-5 h-5 text-white drop-shadow-lg" />
                    </motion.div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Lightbox Modal */}
      {lightboxOpen && (
        <motion.div
          className="fixed inset-0 bg-black/95 z-[200] flex items-center justify-center p-4 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={closeLightbox}
        >
          <motion.div
            className="relative w-full h-full max-w-7xl max-h-[95vh] flex items-center justify-center select-none"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            onWheel={handleWheel}
          >
            {/* Image Container */}
            <motion.div
              className="relative w-full h-full flex items-center justify-center"
              animate={{ x: pan.x, y: pan.y }}
              transition={{ type: "spring", stiffness: 400, damping: 30 }}
            >
              <motion.div
                animate={{ scale: zoom }}
                transition={{ type: "spring", stiffness: 400, damping: 30 }}
                className="relative w-full h-full max-w-6xl max-h-[90vh]"
              >
                <Image
                  src={images[selectedImageIndex].src}
                  alt={images[selectedImageIndex].alt || ""}
                  fill
                  sizes="90vw"
                  className="object-contain select-none pointer-events-none"
                  priority
                  draggable={false}
                />
              </motion.div>
            </motion.div>

            {/* Close Button */}
            <motion.button
              onClick={closeLightbox}
              className="absolute top-6 right-6 text-white hover:text-gray-300 transition-colors p-2 hover:bg-white/10 rounded-full backdrop-blur-sm"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <X className="w-8 h-8" />
            </motion.button>

            {/* Image counter */}
            <div className="absolute top-6 left-6 text-white/70 text-sm font-medium backdrop-blur-sm bg-white/10 px-4 py-2 rounded-full">
              {selectedImageIndex + 1} / {images.length}
            </div>

            {/* Navigation buttons */}
            <div className="absolute left-6 top-1/2 transform -translate-y-1/2 flex gap-4">
              <motion.button
                onClick={() => {
                  const newIndex = selectedImageIndex === 0 ? images.length - 1 : selectedImageIndex - 1;
                  setSelectedImageIndex(newIndex);
                  setZoom(1);
                  setPan({ x: 0, y: 0 });
                }}
                className="text-white hover:text-gray-300 p-3 hover:bg-white/10 rounded-full backdrop-blur-sm"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </motion.button>
            </div>

            <div className="absolute right-6 top-1/2 transform -translate-y-1/2 flex gap-4">
              <motion.button
                onClick={() => {
                  const newIndex = selectedImageIndex === images.length - 1 ? 0 : selectedImageIndex + 1;
                  setSelectedImageIndex(newIndex);
                  setZoom(1);
                  setPan({ x: 0, y: 0 });
                }}
                className="text-white hover:text-gray-300 p-3 hover:bg-white/10 rounded-full backdrop-blur-sm"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </motion.button>
            </div>

            {/* Zoom Controls */}
            <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 bg-white/10 backdrop-blur-xl rounded-full px-6 py-4 flex items-center gap-4 border border-white/30 shadow-2xl">
              <motion.button
                onClick={() => setZoom(Math.max(1, zoom - 0.2))}
                className="text-white hover:text-gray-300 transition-colors p-2 hover:bg-white/10 rounded-full disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={zoom <= 1}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM13 10H7" />
                </svg>
              </motion.button>
              <span className="text-white text-sm font-medium min-w-[60px] text-center">
                {Math.round(zoom * 100)}%
              </span>
              <motion.button
                onClick={() => setZoom(Math.min(4, zoom + 0.2))}
                className="text-white hover:text-gray-300 transition-colors p-2 hover:bg-white/10 rounded-full disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={zoom >= 4}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v6m3-3H7" />
                </svg>
              </motion.button>
              <div className="w-px h-6 bg-white/20" />
              <motion.button
                onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }}
                className="text-white hover:text-gray-300 transition-colors px-4 py-1 hover:bg-white/10 rounded text-sm font-medium"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Reset
              </motion.button>
            </div>

            {/* Instructions */}
            <motion.div 
              className="absolute top-8 left-8 text-white/70 text-sm space-y-2 pointer-events-none"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <p>• Cuộn chuột để phóng to/thu nhỏ</p>
              <p>• Kéo ảnh để di chuyển khi phóng to</p>
              <p>• Dùng mũi tên hoặc ESC để thoát</p>
            </motion.div>
          </motion.div>
        </motion.div>
      )}
    </>
  );
}
