"use client";

import { useState } from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import { X, ZoomIn } from "lucide-react";

interface EditorialImageProps {
  src: string;
  alt?: string;
  caption?: string;
  variant?: "contained" | "full" | "offset";
}

export function EditorialImage({
  src,
  alt = "",
  caption,
  variant = "contained",
}: EditorialImageProps) {
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  // Lightbox handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    if (zoom === 1) return;
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || zoom === 1) return;
    const newX = e.clientX - dragStart.x;
    const newY = e.clientY - dragStart.y;
    const maxPan = (zoom - 1) * 150;
    setPan({
      x: Math.max(-maxPan, Math.min(maxPan, newX)),
      y: Math.max(-maxPan, Math.min(maxPan, newY)),
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const zoomSpeed = 0.15;
    const newZoom = e.deltaY > 0 
      ? Math.max(1, zoom - zoomSpeed) 
      : Math.min(4, zoom + zoomSpeed);
    setZoom(newZoom);
    if (newZoom === 1) {
      setPan({ x: 0, y: 0 });
    }
  };

  const handleClose = () => {
    setIsLightboxOpen(false);
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  const handleLightboxClick = () => {
    setIsLightboxOpen(true);
  };

  // Render different variants
  if (variant === "full") {
    return (
      <>
        <div 
          className="w-screen relative left-1/2 -translate-x-1/2 my-16 md:my-32 cursor-pointer group"
          onClick={handleLightboxClick}
        >
          <div className="relative h-[50vh] md:h-[70vh] overflow-hidden bg-[#F8F7F4]">
            <Image 
              src={src} 
              alt={alt} 
              fill 
              className="object-contain group-hover:opacity-90 transition-opacity" 
            />
            
            {/* Zoom Hint */}
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors flex items-center justify-center">
              <motion.div 
                className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-3"
                initial={{ scale: 0.8 }}
                whileHover={{ scale: 1 }}
              >
                <ZoomIn className="w-6 h-6 text-gray-600 drop-shadow-lg" />
                <span className="text-base text-gray-600 font-medium drop-shadow-lg">Nhấp để phóng to</span>
              </motion.div>
            </div>
          </div>
          {caption && (
            <p className="text-center text-xs mt-4 text-gray-400 px-6">
              {caption}
            </p>
          )}
        </div>

        {/* Lightbox Modal */}
        {isLightboxOpen && (
          <motion.div
            className="fixed inset-0 bg-black/95 z-[200] flex items-center justify-center p-4 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleClose}
          >
            <motion.div
              className="relative w-full h-full max-w-7xl max-h-[95vh] flex items-center justify-center select-none"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
              onWheel={handleWheel}
            >
              {/* Image Container */}
              <motion.div
                className="relative w-full h-full flex items-center justify-center"
                animate={{ x: pan.x, y: pan.y }}
                transition={{ type: "spring", stiffness: 400, damping: 30 }}
              >
                <motion.div
                  animate={{ scale: zoom }}
                  transition={{ type: "spring", stiffness: 400, damping: 30 }}
                  className="relative w-full h-full max-w-6xl max-h-[90vh]"
                >
                  <Image
                    src={src}
                    alt={alt}
                    fill
                    sizes="90vw"
                    className="object-contain select-none pointer-events-none"
                    priority
                    draggable={false}
                  />
                </motion.div>
              </motion.div>

              {/* Close Button */}
              <motion.button
                onClick={handleClose}
                className="absolute top-6 right-6 text-white hover:text-gray-300 transition-colors p-2 hover:bg-white/10 rounded-full backdrop-blur-sm"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
              >
                <X className="w-8 h-8" />
              </motion.button>

              {/* Zoom Controls */}
              <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 bg-white/10 backdrop-blur-xl rounded-full px-6 py-4 flex items-center gap-4 border border-white/30 shadow-2xl">
                <motion.button
                  onClick={() => setZoom(Math.max(1, zoom - 0.2))}
                  className="text-white hover:text-gray-300 transition-colors p-2 hover:bg-white/10 rounded-full disabled:opacity-50"
                  disabled={zoom <= 1}
                  whileHover={{ scale: 1.1 }}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM13 10H7" />
                  </svg>
                </motion.button>
                <span className="text-white text-sm font-medium min-w-[60px] text-center">
                  {Math.round(zoom * 100)}%
                </span>
                <motion.button
                  onClick={() => setZoom(Math.min(4, zoom + 0.2))}
                  className="text-white hover:text-gray-300 transition-colors p-2 hover:bg-white/10 rounded-full disabled:opacity-50"
                  disabled={zoom >= 4}
                  whileHover={{ scale: 1.1 }}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v6m3-3H7" />
                  </svg>
                </motion.button>
                <div className="w-px h-6 bg-white/20" />
                <motion.button
                  onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }}
                  className="text-white hover:text-gray-300 px-4 py-1 hover:bg-white/10 rounded text-sm font-medium"
                  whileHover={{ scale: 1.05 }}
                >
                  Reset
                </motion.button>
              </div>

              {/* Instructions */}
              <motion.div 
                className="absolute top-8 left-8 text-white/70 text-sm space-y-2 pointer-events-none"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                <p>• Cuộn chuột để phóng to/thu nhỏ</p>
                <p>• Kéo ảnh để di chuyển khi phóng to</p>
                <p>• Nhấn ESC hoặc click X để thoát</p>
              </motion.div>
            </motion.div>
          </motion.div>
        )}
      </>
    );
  }

  if (variant === "offset") {
    return (
      <>
        <div 
          className="my-20 md:my-28 grid grid-cols-12 cursor-pointer"
          onClick={handleLightboxClick}
        >
          <div className="col-span-10 col-start-2 md:col-span-7 md:col-start-5 group">
            <div className="relative aspect-[4/5] bg-[#F8F7F4] overflow-hidden rounded-lg">
              <Image 
                src={src} 
                alt={alt} 
                fill 
                className="object-contain group-hover:opacity-90 transition-opacity" 
              />
              
              {/* Zoom Hint */}
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors flex items-center justify-center">
                <motion.div 
                  className="opacity-0 group-hover:opacity-100 transition-opacity"
                  initial={{ scale: 0.8 }}
                  whileHover={{ scale: 1 }}
                >
                  <ZoomIn className="w-5 h-5 text-gray-600" />
                </motion.div>
              </div>
            </div>
            {caption && (
              <p className="text-xs mt-4 text-gray-400">
                {caption}
              </p>
            )}
          </div>
        </div>

        {/* Lightbox Modal */}
        {isLightboxOpen && (
          <motion.div
            className="fixed inset-0 bg-black/95 z-[200] flex items-center justify-center p-4 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            onClick={handleClose}
          >
            <motion.div
              className="relative w-full h-full max-w-7xl max-h-[95vh] flex items-center justify-center select-none"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              onClick={(e) => e.stopPropagation()}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
              onWheel={handleWheel}
            >
              <motion.div
                className="relative w-full h-full flex items-center justify-center"
                animate={{ x: pan.x, y: pan.y }}
                transition={{ type: "spring", stiffness: 400, damping: 30 }}
              >
                <motion.div
                  animate={{ scale: zoom }}
                  transition={{ type: "spring", stiffness: 400, damping: 30 }}
                  className="relative w-full h-full max-w-6xl max-h-[90vh]"
                >
                  <Image
                    src={src}
                    alt={alt}
                    fill
                    sizes="90vw"
                    className="object-contain select-none pointer-events-none"
                    priority
                    draggable={false}
                  />
                </motion.div>
              </motion.div>

              <motion.button
                onClick={handleClose}
                className="absolute top-6 right-6 text-white hover:text-gray-300 p-2 hover:bg-white/10 rounded-full"
                whileHover={{ scale: 1.1 }}
              >
                <X className="w-8 h-8" />
              </motion.button>

              <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 bg-white/10 backdrop-blur-xl rounded-full px-6 py-4 flex items-center gap-4 border border-white/30">
                <button
                  onClick={() => setZoom(Math.max(1, zoom - 0.2))}
                  disabled={zoom <= 1}
                  className="text-white hover:text-gray-300 p-2 hover:bg-white/10 rounded-full disabled:opacity-50"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM13 10H7" />
                  </svg>
                </button>
                <span className="text-white text-sm font-medium min-w-[60px] text-center">{Math.round(zoom * 100)}%</span>
                <button
                  onClick={() => setZoom(Math.min(4, zoom + 0.2))}
                  disabled={zoom >= 4}
                  className="text-white hover:text-gray-300 p-2 hover:bg-white/10 rounded-full disabled:opacity-50"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v6m3-3H7" />
                  </svg>
                </button>
                <div className="w-px h-6 bg-white/20" />
                <button
                  onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }}
                  className="text-white px-4 py-1 hover:bg-white/10 rounded text-sm"
                >
                  Reset
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </>
    );
  }

  // Default contained variant
  return (
    <>
      <div 
        className="my-16 md:my-24 cursor-pointer group"
        onClick={handleLightboxClick}
      >
        <div className="relative aspect-[16/10] w-full bg-[#F8F7F4] overflow-hidden rounded-lg">
          <Image 
            src={src} 
            alt={alt} 
            fill 
            className="object-contain group-hover:opacity-90 transition-opacity" 
          />
          
          {/* Zoom Hint */}
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors flex items-center justify-center">
            <motion.div 
              className="opacity-0 group-hover:opacity-100 transition-opacity"
              initial={{ scale: 0.8 }}
              whileHover={{ scale: 1 }}
            >
              <ZoomIn className="w-5 h-5 text-gray-600" />
            </motion.div>
          </div>
        </div>
        {caption && (
          <p className="text-xs mt-3 text-gray-400">
            {caption}
          </p>
        )}
      </div>

      {/* Lightbox Modal */}
      {isLightboxOpen && (
        <motion.div
          className="fixed inset-0 bg-black/95 z-[200] flex items-center justify-center p-4 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          onClick={handleClose}
        >
          <motion.div
            className="relative w-full h-full max-w-7xl max-h-[95vh] flex items-center justify-center select-none"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            onClick={(e) => e.stopPropagation()}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            onWheel={handleWheel}
          >
            <motion.div
              className="relative w-full h-full flex items-center justify-center"
              animate={{ x: pan.x, y: pan.y }}
              transition={{ type: "spring", stiffness: 400, damping: 30 }}
            >
              <motion.div
                animate={{ scale: zoom }}
                transition={{ type: "spring", stiffness: 400, damping: 30 }}
                className="relative w-full h-full max-w-6xl max-h-[90vh]"
              >
                <Image
                  src={src}
                  alt={alt}
                  fill
                  sizes="90vw"
                  className="object-contain select-none pointer-events-none"
                  priority
                  draggable={false}
                />
              </motion.div>
            </motion.div>

            <motion.button
              onClick={handleClose}
              className="absolute top-6 right-6 text-white hover:text-gray-300 p-2 hover:bg-white/10 rounded-full"
              whileHover={{ scale: 1.1 }}
            >
              <X className="w-8 h-8" />
            </motion.button>

            <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 bg-white/10 backdrop-blur-xl rounded-full px-6 py-4 flex items-center gap-4 border border-white/30">
              <button
                onClick={() => setZoom(Math.max(1, zoom - 0.2))}
                disabled={zoom <= 1}
                className="text-white hover:text-gray-300 p-2 hover:bg-white/10 rounded-full disabled:opacity-50"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM13 10H7" />
                </svg>
              </button>
              <span className="text-white text-sm font-medium min-w-[60px] text-center">{Math.round(zoom * 100)}%</span>
              <button
                onClick={() => setZoom(Math.min(4, zoom + 0.2))}
                disabled={zoom >= 4}
                className="text-white hover:text-gray-300 p-2 hover:bg-white/10 rounded-full disabled:opacity-50"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v6m3-3H7" />
                </svg>
              </button>
              <div className="w-px h-6 bg-white/20" />
              <button
                onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }}
                className="text-white px-4 py-1 hover:bg-white/10 rounded text-sm"
              >
                Reset
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </>
  );
}
