"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { motion, useScroll, useSpring, useTransform } from "framer-motion";
import { ArrowLeft, Clock, User, Tag, Share2 } from "lucide-react";
import Header from "@/components/shared/header";
import Footer from "@/components/shared/footer";
import BookingModal from "@/components/booking/booking-modal";
import { ArticleRenderer } from "@/components/editorial/ArticleRenderer";
import { useLanguage } from "@/lib/language-context";
import { Post } from "@/lib/data/editorial";

export default function ArticleClient({ post, related }: { post: Post; related: Post[] }) {
  const { language, t } = useLanguage();
  const [isBookingOpen, setIsBookingOpen] = useState(false);

  const lang = language === "VN" ? "VN" : (language === "KR" ? "KR" : (language === "CN" ? "CN" : (language === "RU" ? "RU" : "EN")));

  // Scroll progress for reading experience
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001,
  });

  const imageScale = useTransform(scrollYProgress, [0, 0.3], [1, 1.1]);
  const imageOpacity = useTransform(scrollYProgress, [0, 0.3], [1, 0.9]);

  // Helper functions to get localized content
  const getTitle = (p: Post) => {
    if (lang === "VN") return p.title_vn;
    if (lang === "KR") return p.title_kr || p.title_en;
    if (lang === "CN") return p.title_cn || p.title_en;
    if (lang === "RU") return p.title_ru || p.title_en;
    return p.title_en;
  };

  const getCategory = (p: Post) => {
    if (lang === "VN") return p.category_vn;
    if (lang === "KR") return p.category_kr || p.category_en;
    if (lang === "CN") return p.category_cn || p.category_en;
    if (lang === "RU") return p.category_ru || p.category_en;
    return p.category_en;
  };

  const getReadTime = (p: Post) => {
    if (lang === "VN") return p.read_time_vn;
    if (lang === "KR") return p.read_time_kr || p.read_time_en;
    if (lang === "CN") return p.read_time_cn || p.read_time_en;
    if (lang === "RU") return p.read_time_ru || p.read_time_en;
    return p.read_time_en;
  };

  const getExcerpt = (p: Post) => {
    if (lang === "VN") return p.excerpt_vn;
    if (lang === "KR") return p.excerpt_kr || p.excerpt_en;
    if (lang === "CN") return p.excerpt_cn || p.excerpt_en;
    if (lang === "RU") return p.excerpt_ru || p.excerpt_en;
    return p.excerpt_en;
  };

  const getBody = (p: Post) => {
    if (lang === "VN") return p.body_vn;
    if (lang === "KR") return p.body_kr || p.body_en;
    if (lang === "CN") return p.body_cn || p.body_en;
    if (lang === "RU") return p.body_ru || p.body_en;
    return p.body_en;
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return "";
    const date = new Date(dateStr);
    if (lang === "VN") {
      return `${date.getDate()} Thg ${date.getMonth() + 1}, ${date.getFullYear()}`;
    }
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  };

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.21, 0.47, 0.32, 0.98],
      },
    },
  };

  // Convert body text to blocks for renderer
  const bodyBlocks = getBody(post)
    ?.split("\n\n")
    .filter((line) => line.trim())
    .map((line, i) => ({
      type: "text" as const,
      content: line.trim(),
    })) || [];

  return (
    <main className="relative bg-white min-h-screen selection:bg-[#735c00]/10">
      {/* Reading Progress Bar */}
      <motion.div
        className="fixed top-0 left-0 right-0 h-[3px] bg-[#735c00] z-[100] origin-left"
        style={{ scaleX }}
      />

      <Header onOpenBooking={() => setIsBookingOpen(true)} />

      {/* ──── HERO SECTION ──── */}
      <section className="relative w-full h-[70vh] md:h-[85vh] overflow-hidden bg-[#F8F7F4]">
        <motion.div
          style={{ scale: imageScale, opacity: imageOpacity }}
          className="absolute inset-0"
        >
          <Image
            src={post.cover_image_url || "/placeholder.jpg"}
            alt={getTitle(post) || ""}
            fill
            priority
            sizes="100vw"
            className="object-cover"
          />
        </motion.div>

        {/* Hero overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-black/20 to-transparent" />

        {/* Hero content */}
        <motion.div
          className="absolute inset-0 flex flex-col justify-end p-6 md:p-12 lg:p-16"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.div variants={itemVariants} className="max-w-[900px]">
            <p className="text-[10px] tracking-[0.4em] uppercase text-white/70 mb-6 font-bold">
              {getCategory(post)}
            </p>

            <h1 className="font-serif text-4xl md:text-6xl lg:text-7xl leading-[1.1] tracking-tight text-white font-light mb-8">
              {getTitle(post)}
            </h1>

            <div className="flex items-center gap-8 flex-wrap text-white/70">
              <span className="flex items-center gap-2.5 font-sans text-[9px] uppercase tracking-[0.25em]">
                <Clock className="w-3 h-3" />
                {getReadTime(post)}
              </span>
              <span className="flex items-center gap-2.5 font-sans text-[9px] uppercase tracking-[0.25em]">
                <User className="w-3 h-3" />
                {post.author}
              </span>
              <span className="font-sans text-[9px] uppercase tracking-[0.25em]">
                {formatDate(post.published_date || post.created_at)}
              </span>
            </div>
          </motion.div>
        </motion.div>
      </section>

      {/* ──── ARTICLE SECTION ──── */}
      <article className="max-w-[860px] mx-auto px-6 md:px-12 pt-24 md:pt-32 pb-32">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* Back Link & Share */}
          <motion.div variants={itemVariants} className="flex justify-between items-center mb-16">
            <Link
              href="/editorial"
              className="group flex items-center gap-3 text-[#1b1c19]/40 hover:text-[#735c00] transition-all duration-300"
            >
              <div className="w-8 h-8 rounded-full border border-gray-200 flex items-center justify-center group-hover:border-[#735c00]/30 group-hover:bg-[#735c00]/5 transition-all">
                <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-1 transition-transform" />
              </div>
              <span className="text-[10px] font-sans uppercase tracking-[0.3em] font-medium">
                {lang === "VN" ? "Quay lại" : lang === "RU" ? "Назад" : lang === "KR" ? "뒤로 가기" : lang === "CN" ? "返回" : "Back"}
              </span>
            </Link>
            <button className="w-10 h-10 rounded-full border border-gray-100 flex items-center justify-center text-gray-400 hover:text-[#735c00] hover:bg-white transition-all shadow-sm">
              <Share2 className="w-4 h-4" />
            </button>
          </motion.div>

          {/* Excerpt */}
          <motion.div variants={itemVariants} className="my-16 relative pl-8 border-l-2 border-[#735c00]/20">
            <p className="font-serif text-2xl md:text-3xl italic text-gray-700 leading-relaxed font-light">
              {getExcerpt(post)}
            </p>
          </motion.div>

          {/* Body using ArticleRenderer */}
          <motion.div variants={itemVariants}>
            <ArticleRenderer blocks={bodyBlocks} />
          </motion.div>

          {/* CTA Card */}
          <motion.div variants={itemVariants} className="mt-32 relative group overflow-hidden">
            <div className="absolute inset-0 bg-[#1b1c19] translate-y-full group-hover:translate-y-0 transition-transform duration-700 ease-[0.21,0.47,0.32,0.98]" />
            <div className="relative p-12 md:p-16 border border-[#735c00]/20 bg-white/50 backdrop-blur-sm flex flex-col items-start gap-10 group-hover:border-[#735c00]/50 transition-colors duration-500">
              <div className="space-y-3">
                <p className="font-sans text-[10px] uppercase tracking-[0.4em] text-[#735c00] font-bold group-hover:text-white/60 transition-colors">
                  {t("ed-discover")}
                </p>
                <h3 className="font-serif text-3xl md:text-4xl text-[#1b1c19] font-light group-hover:text-white transition-colors">
                  {t("ed-craft")}
                </h3>
              </div>
              <button
                onClick={() => setIsBookingOpen(true)}
                className="px-12 py-5 text-white font-serif uppercase tracking-[0.25em] text-xs transition-all duration-500 hover:shadow-[0_20px_50px_rgba(115,92,0,0.2)]"
                style={{ background: "linear-gradient(90deg, #735c00 0%, #d4af37 100%)" }}
              >
                {t("ed-book")}
              </button>
            </div>
          </motion.div>
        </motion.div>
      </article>

      {/* ──── RELATED ARTICLES ──── */}
      {related.length > 0 && (
        <section className="max-w-[860px] mx-auto px-6 md:px-12 pb-32">
          <div className="border-t border-gray-100 pt-16">
            <p className="font-sans text-[10px] uppercase tracking-[0.4em] text-gray-400 mb-16">
              {t("ed-related")}
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
              {related.map((r) => (
                <Link
                  key={r.id}
                  href={`/editorial/${r.slug}`}
                  className="group flex flex-col md:flex-row gap-8 items-start"
                >
                  <div className="relative w-full md:w-40 aspect-[4/3] flex-shrink-0 overflow-hidden bg-gray-100 rounded">
                    <Image
                      src={r.cover_image_url || "/placeholder-image.jpg"}
                      alt={getTitle(r)}
                      fill
                      className="object-cover grayscale group-hover:grayscale-0 group-hover:scale-110 transition-all duration-1000 ease-out"
                    />
                  </div>
                  <div className="space-y-4 pt-2">
                    <span className="font-sans text-[9px] uppercase tracking-[0.3em] text-[#735c00] font-bold">
                      {getCategory(r)}
                    </span>
                    <h4 className="font-serif text-2xl text-[#1b1c19] font-light leading-snug group-hover:text-[#735c00] transition-colors duration-500">
                      {getTitle(r)}
                    </h4>
                    <div className="flex items-center gap-4 text-gray-400">
                      <div className="h-px w-6 bg-gray-200" />
                      <p className="font-sans text-[9px] uppercase tracking-[0.25em]">
                        {getReadTime(r)}
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      <BookingModal isOpen={isBookingOpen} onClose={() => setIsBookingOpen(false)} />
      <Footer />
    </main>
  );
}
